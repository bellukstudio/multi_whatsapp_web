import 'dart:async';
import 'dart:collection';
import 'dart:io' show Platform;

import 'package:multi_whatsapp_web/core/constants/app_constants.dart';
import 'package:multi_whatsapp_web/core/utils/memory_profiler.dart';
import 'package:multi_whatsapp_web/domain/entities/account.dart';
import 'package:multi_whatsapp_web/domain/repositories/webview_adapter.dart';

/// Desktop-only session pool with a soft LRU cap (PRD §26: "10 akun:
/// tidak crash, resource dimonitor" — read as "don't let 10 open accounts
/// mean 10 fully-rendering WebViews forever").
///
/// Policy:
///   - Up to [maxWarmSessions] accounts may have a live WebView at once.
///   - The currently *visible* account is always kept fully active.
///   - Other warm accounts are [WebViewAdapter.pauseRendering]'d (cheap —
///     keeps cookies/DOM state, throttles JS) rather than unloaded.
///   - When a session beyond the cap is requested, the Least Recently
///     Used warm session is evicted via [WebViewAdapter.unloadFromMemory]
///     + [WebViewSessionHandle.dispose] before the new one is created.
///   - ENHANCEMENT (memory footprint): paused-but-warm accounts no longer
///     wait for the LRU cap to be hit before releasing memory. A
///     periodic sweep (see [_idleSweepTimer]) fully unloads any warm,
///     non-active account that has sat paused for longer than
///     [idleEvictionTimeout] — e.g. leaving 3 accounts open but only
///     actually using 1 all day used to keep the other 2 resident
///     indefinitely (just throttled via visibilitychange, not released)
///     until a 4th account happened to push them past the cap. Now they
///     get fully released after being idle for a while, and are simply
///     recreated (same as any cold session) the next time you switch
///     back to them.
///
/// Mobile does NOT use this pool — [SessionCubit] talks to the adapter
/// directly there, since §27 mandates at most one warm session, period.
class SessionPoolManager {
  SessionPoolManager({
    required WebViewAdapter webViewAdapter,
    int? maxWarmSessions,
    Duration? idleEvictionTimeout,
    Duration? idleSweepInterval,
  }) : _adapter = webViewAdapter,
       _maxWarmSessions =
           maxWarmSessions ?? AppConstants.maxRecommendedDesktopSessions,
       _idleEvictionTimeout =
           idleEvictionTimeout ?? const Duration(minutes: 10) {
    // Sweeps at a fraction of the eviction timeout so an idle account
    // never sits resident much longer than the configured timeout, but
    // without polling so often it costs anything noticeable itself.
    final interval =
        idleSweepInterval ??
        Duration(
          seconds: (_idleEvictionTimeout.inSeconds / 2).clamp(30, 300).toInt(),
        );
    _idleSweepTimer = Timer.periodic(interval, (_) => _sweepIdleSessions());
  }

  final WebViewAdapter _adapter;
  final int _maxWarmSessions;
  final Duration _idleEvictionTimeout;
  late final Timer _idleSweepTimer;

  /// LinkedHashMap preserves insertion order; we re-insert on access to
  /// get cheap LRU-order tracking (oldest = least recently used = first).
  final LinkedHashMap<String, WebViewSessionHandle> _warm =
      LinkedHashMap<String, WebViewSessionHandle>();

  /// When each currently-warm-but-not-active account was last paused —
  /// i.e. when it stopped being the visible/active session. Used by
  /// [_sweepIdleSessions] to find accounts that have been sitting idle
  /// too long. Cleared for an account the moment it becomes active again
  /// (see [_acquireLocked]/[_pauseIfStillWarm]).
  final Map<String, DateTime> _pausedSince = {};

  String? _activeAccountId;

  /// Serializes [acquire] calls so two overlapping calls (e.g. the user
  /// tapping two different accounts before the first switch has finished)
  /// can never both pass the `_warm.length >= _maxWarmSessions` check
  /// before either has updated [_warm]. Without this, two concurrent
  /// `createOrResumeSession` calls can both reach
  /// `WebviewController.initialize()` at the same time — on Windows that
  /// means two `DispatcherQueueController`s on one thread, which is
  /// exactly what produces `PlatformException(unsupported_platform, "The
  /// platform is not supported")` (webview_windows only allows one; see
  /// the FIX note in SessionCubit / jnschulze/flutter-webview-windows#119).
  Future<void> _lock = Future<void>.value();

  int get warmCount => _warm.length;

  /// Makes [account] the active, fully-rendering session. Evicts the LRU
  /// warm session first if the pool is at capacity and [account] isn't
  /// already warm.
  Future<WebViewSessionHandle> acquire(Account account) {
    final result = _lock.then((_) => _acquireLocked(account));
    // Keep the chain alive even if this acquire failed, so the *next*
    // caller still waits for it instead of racing it.
    _lock = result.then((_) {}, onError: (_) {});
    return result;
  }

  Future<WebViewSessionHandle> _acquireLocked(Account account) async {
    final previousActiveId = _activeAccountId;

    // ignore: avoid_print
    print(
      '[SessionPoolManager] acquire(${account.id}) — warmCount=${_warm.length} '
      '(cap=$_maxWarmSessions), already warm=${_warm.containsKey(account.id)}, '
      'warm ids=${_warm.keys.toList()}',
    );

    if (_warm.containsKey(account.id)) {
      // Already warm — just promote to MRU and resume full rendering.
      final handle = _warm.remove(account.id)!;
      _warm[account.id] = handle; // re-insert = move to MRU end
      await handle.resumeRendering();
      _activeAccountId = account.id;
      _pausedSince.remove(account.id);
      await _pauseIfStillWarm(previousActiveId);
      return handle;
    }

    if (_warm.length >= _maxWarmSessions) {
      await _evictLeastRecentlyUsed();
    }

    final handle = await MemoryProfiler.logAround(
      'create session ${account.id}',
      () => _adapter.createOrResumeSession(
        accountId: account.id,
        sessionPath: account.sessionPath,
      ),
    );

    // FIX (bug: 2nd account fails forever with
    // PlatformException(environment_already_initialized, ...) even
    // though only ONE account should ever be warm at a time on
    // Windows): this used to register `handle` into `_warm` AFTER
    // `await handle.navigateToWhatsAppWeb()`. If navigation threw for
    // ANY reason (transient WebView2 hiccup, network blip, etc.), that
    // line was never reached — the controller (and, on Windows, its
    // hold on the ONE shared WebView2 environment) stayed alive, but
    // nothing tracked it in `_warm`. `warmCount` then read back as 0,
    // so no eviction ever triggered before the NEXT account tried to
    // acquire — meanwhile the orphaned first controller's environment
    // reference was NEVER released (nothing ever called
    // unloadFromMemory()/dispose() on it, since the pool didn't know it
    // existed), so the shared environment stayed permanently locked to
    // that first account's userDataPath. Every subsequent account would
    // then fail `initializeEnvironment()` for as long as the app kept
    // running.
    //
    // Now: register in `_warm` FIRST (before navigation), so a failed
    // navigateToWhatsAppWeb() still leaves the controller reachable for
    // normal eviction/dispose — never an untracked, permanently-alive
    // orphan holding the shared environment hostage.
    _warm[account.id] = handle;
    _activeAccountId = account.id;
    _pausedSince.remove(account.id);

    try {
      await handle.navigateToWhatsAppWeb();
    } catch (e) {
      // Navigation failed, but the handle stays in `_warm` (see above) so
      // it will be picked up by normal LRU/idle eviction instead of
      // leaking. Surface the failure to the caller (SessionCubit already
      // has a catch block around `_pool!.acquire()` that turns this into
      // an error state) rather than silently swallowing it.
      rethrow;
    }

    await _pauseIfStillWarm(previousActiveId);
    return handle;
  }

  Future<void> _pauseIfStillWarm(String? accountId) async {
    if (accountId == null || accountId == _activeAccountId) return;
    final handle = _warm[accountId];
    if (handle != null) {
      await handle.pauseRendering();
      _pausedSince[accountId] = DateTime.now();
    }
  }

  /// Periodic sweep (see constructor) that fully unloads any warm,
  /// non-active account that has been paused for longer than
  /// [_idleEvictionTimeout] — the memory-footprint enhancement described
  /// in the class doc. Runs independently of [acquire]/eviction-by-cap,
  /// so idle accounts release memory even while well under
  /// [_maxWarmSessions].
  Future<void> _sweepIdleSessions() async {
    final now = DateTime.now();
    final idleIds = _pausedSince.entries
        .where((e) => now.difference(e.value) >= _idleEvictionTimeout)
        .map((e) => e.key)
        .toList(growable: false);

    for (final id in idleIds) {
      if (id == _activeAccountId) {
        // Shouldn't happen (active accounts are removed from
        // _pausedSince), but never unload the visible session.
        _pausedSince.remove(id);
        continue;
      }
      final handle = _warm.remove(id);
      _pausedSince.remove(id);
      if (handle == null) continue;
      await MemoryProfiler.logAround(
        'idle-unload session $id (paused >= ${_idleEvictionTimeout.inMinutes}m)',
        () async {
          await handle.unloadFromMemory();
          await handle.dispose();
        },
      );
    }
  }

  Future<void> _evictLeastRecentlyUsed() async {
    if (_warm.isEmpty) return;
    final lruId = _warm.keys.first; // first-inserted = least recently used

    // FIX (root cause of "add/switch account gagal terus dengan
    // PlatformException(environment_already_initialized, ...)" pada
    // Windows, cap=1): this used to bail out early with
    // `if (lruId == _activeAccountId) return;` — a guard meant to avoid
    // evicting an already-visible session in the general (cap > 1)
    // case. But `_evictLeastRecentlyUsed()` is ONLY ever called from
    // `_acquireLocked` right before creating a session for a genuinely
    // DIFFERENT account (the `_warm.containsKey(account.id)` check above
    // it already returned false) — so by definition we are in the
    // middle of switching AWAY from whatever is currently active. With
    // `maxWarmSessions == 1` (Windows), the only entry in `_warm` is
    // ALWAYS the current `_activeAccountId`, so this guard made eviction
    // a permanent no-op on Windows: the first account's WebView2
    // controller/environment was NEVER released, so every subsequent
    // account's `initializeEnvironment()` call failed forever with
    // "environment_already_initialized" — confirmed by
    // `warmCount=1`/`warm ids=[<first account>]` staying unchanged
    // across every later acquire() in the logs. Removing the guard:
    // evicting the "active" entry here is exactly correct, since the
    // caller is already committed to making a different account active
    // right after this returns.
    final handle = _warm.remove(lruId);
    _pausedSince.remove(lruId);
    if (handle != null) {
      await MemoryProfiler.logAround('evict LRU session $lruId', () async {
        await handle.unloadFromMemory();
        await handle.dispose();
      });
      // WORKAROUND: on Windows, WebviewController.dispose() tears down
      // the native WebView2 environment/process *asynchronously* — the
      // awaited Future above can resolve before that teardown is
      // actually done. Creating the next WebviewController (and
      // reconfiguring the shared environment to the new account's
      // userDataPath) immediately after can still race the previous
      // one's cleanup.
      //
      // BUG THIS CAUSED (fixed alongside this delay bump): when the
      // race was lost, windows_webview_adapter.dart used to silently let
      // the new account join the OLD (not-yet-torn-down) environment
      // instead of failing — i.e. two accounts would silently share one
      // WhatsApp Web cookie/localStorage profile, which WhatsApp Web
      // then treats as the same session opened twice and force-logs out
      // BOTH sides. windows_webview_adapter.dart now retries with
      // backoff (up to ~5.4s total) instead of silently sharing, so a
      // slow teardown here just means a slightly slower switch, not a
      // silent data-isolation bug. This delay is a first line of
      // defense to make that retry path rarely needed in practice, not
      // the only thing preventing the bug anymore.
      if (Platform.isWindows) {
        await Future<void>.delayed(const Duration(milliseconds: 1200));
      }
    }
  }

  /// Optional explicit eviction, e.g. when an account is deleted (§12) —
  /// don't wait for LRU pressure to release its memory.
  Future<void> evict(String accountId) async {
    final handle = _warm.remove(accountId);
    _pausedSince.remove(accountId);
    if (handle == null) return;
    await handle.unloadFromMemory();
    await handle.dispose();
    if (_activeAccountId == accountId) _activeAccountId = null;
  }

  Future<void> disposeAll() async {
    for (final handle in _warm.values) {
      await handle.unloadFromMemory();
      await handle.dispose();
    }
    _warm.clear();
    _pausedSince.clear();
    _activeAccountId = null;
  }

  /// Stops the idle sweep timer. Call this alongside [disposeAll] when
  /// the owning [SessionCubit] itself is closed (e.g. app shutdown) —
  /// otherwise the periodic timer keeps the pool manager (and its
  /// closures) alive indefinitely.
  void dispose() {
    _idleSweepTimer.cancel();
  }
}